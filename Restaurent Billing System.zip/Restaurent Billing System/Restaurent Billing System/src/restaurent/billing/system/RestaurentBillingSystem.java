
package restaurent.billing.system;



public class RestaurentBillingSystem {

   
    public static void main(String[] args) {
       LoginForm l=new LoginForm();
       l.setVisible(true);
       
    }
    
}
